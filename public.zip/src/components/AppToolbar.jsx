import * as React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import {
  FormControl,
  Input,
  InputAdornment,
  InputLabel,
  TextField,
} from "@mui/material";
import { AccountCircle, DarkMode, Person, Search } from "@mui/icons-material";
import { Link } from "react-router-dom";

export default function AppToolbar() {
  return (
    <Box sx={{ flexGrow: 1 }}>
      <AppBar position="static">
        <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
          <Box sx={{ display: { xs: "none", md: "flex" } }}>
            <Link to="/" style={{ textDecoration: "none", color: "inherit" }}>
              <Typography
                variant="h4"
                component="div"
                sx={{ flexGrow: 1, fontWeight: "bold", mr: 2 }}
                size="large"
                edge="start"
                color="inherit"
              >
                BCard
              </Typography>
            </Link>
            <Button color="inherit">ABOUT</Button>
            <Button color="inherit">FAV CARDS</Button>
          </Box>

          <Box
            sx={{
              display: {
                xs: "flex",
                md: "flex",
                alignItems: "center",
                gap: ".5rem",
              },
            }}
          >
            <TextField
              id="input-with-icon-textfield"
              size="small"
              placeholder="Search"
              sx={{ background: "rgb(228,242,253)", borderRadius: "5px" }}
              slotProps={{
                input: {
                  endAdornment: (
                    <InputAdornment position="start">
                      <Search />
                    </InputAdornment>
                  ),
                },
              }}
              variant="outlined"
            />

            <IconButton aria-label="Example">
              <DarkMode sx={{ color: "rgba(0,0,0,0.5)" }} />
            </IconButton>

            <IconButton aria-label="Example" component={Link} to="/login">
              <Person />
            </IconButton>
          </Box>
        </Toolbar>
      </AppBar>
    </Box>
  );
}
