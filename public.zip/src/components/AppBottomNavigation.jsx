import { Favorite, Info } from "@mui/icons-material";
import { BottomNavigation, BottomNavigationAction, CssBaseline, Paper } from "@mui/material";


export default function AppBottomNavigation() {

    return (<Paper sx={{ position: 'fixed', bottom: 4, left: 0, right: 0 }} elevation={3}>
            <CssBaseline />
       <BottomNavigation
                        showLabels
                        value={"Favorites"}
                        onChange={(event, newValue) => {
                           // setValue(newValue);
                        }}
                        >
                        <BottomNavigationAction label="Favorites" icon={<Favorite />} />
                        <BottomNavigationAction label="About" icon={<Info />} />
            </BottomNavigation>
            <CssBaseline />

             </Paper>
             )
}
