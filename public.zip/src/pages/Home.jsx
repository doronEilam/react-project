import BusinessCard from "../components/BusinessCard";

export default function Home() {
  return (
    <div>
      Hello Home page
      <BusinessCard />
    </div>
  );
}
