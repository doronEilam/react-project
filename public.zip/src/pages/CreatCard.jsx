import React, { useState } from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Container from "@mui/material/Container";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import { FormControlLabel } from "@mui/material";
import axios from "axios";
const CreatCard = () => {
  const [formData, setFormData] = useState({
    title: "",
    subtitle: "",
    description: "",
    phone: "",
    email: "",
    web: "",
    imageUrl: "",
    imageAlt: "",
    state: "",
    country: "",
    city: "",
    street: "",
    houseNumber: 0,
    zip: 0,
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleCancel = () => {
    setFormData({
      title: "",
      subtitle: "",
      description: "",
      phone: "",
      email: "",
      web: "",
      imageUrl: "",
      imageAlt: "",
      state: "",
      country: "",
      city: "",
      street: "",
      houseNumber: 0,
      zip: 0,
    });
  };

  const handleRefresh = () => {
    // Add validation logic here
    console.log("Validation logic goes here");
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    debugger;
    try {
      const cardData = {
        title: formData.title,
        subtitle: formData.subtitle,
        description: formData.description,
        phone: formData.phone,
        email: formData.email,
        web: formData.web,
        image: {
          url: formData.imageUrl,
          alt: formData.imageAlt,
        },
        address: {
          state: formData.state,
          country: formData.country,
          city: formData.city,
          street: formData.street,
          houseNumber: parseInt(formData.houseNumber),
          zip: parseInt(formData.zip),
        },
      };
      console.log(JSON.stringify(cardData));
      const response = axios.post("http://localhost:4000/api/cards", cardData, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      console.log(response);
      const data = response.data;

      console.log(data);
    } catch (error) {
      console.log(error);
    }

    console.log(formData);
    // Add submit logic here
    console.log("Submit logic goes here");
  };

  return (
    <Container>
      <Box sx={{ width: "100%", mt: 5 }}>
        <Paper elevation={3}>
          <Grid container spacing={2} sx={{ p: 3 }}>
            <Grid item xs={12}>
              <Typography variant="h4">CreatCard</Typography>
            </Grid>
            <Grid item xs={12}>
              <Box component="form" onSubmit={handleSubmit}>
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="title"
                      name="title"
                      value={formData.title}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="subtitle"
                      name="subtitle"
                      value={formData.subtitle}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="description"
                      name="description"
                      value={formData.description}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="web"
                      name="web"
                      type="web"
                      value={formData.web}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="image URL"
                      name="imageUrl"
                      value={formData.imageUrl}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="image Alt"
                      name="imageAlt"
                      value={formData.imageAlt}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="state"
                      name="state"
                      value={formData.state}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="country"
                      name="country"
                      value={formData.country}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="city"
                      name="city"
                      value={formData.city}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="street"
                      name="street"
                      value={formData.street}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      type="number"
                      label="house Number"
                      name="houseNumber"
                      value={formData.houseNumber}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      type="number"
                      label="zip"
                      name="zip"
                      value={formData.zip}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Grid container spacing={2}>
                      <Grid item xs={12}>
                        <Button
                          variant="contained"
                          color="secondary"
                          onClick={handleCancel}
                        >
                          Cancel
                        </Button>
                      </Grid>
                      <Grid item xs={12}>
                        <Button
                          variant="contained"
                          color="primary"
                          onClick={handleRefresh}
                        >
                          Refresh
                        </Button>
                      </Grid>
                      <Grid item xs={12}>
                        <Button
                          variant="contained"
                          color="primary"
                          type="submit"
                        >
                          Submit
                        </Button>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Box>
            </Grid>
          </Grid>
        </Paper>
      </Box>
    </Container>
  );
};

export default CreatCard;
