import React, { useState } from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import Container from "@mui/material/Container";
import Paper from "@mui/material/Paper";
import Grid from "@mui/material/Grid";
import Button from "@mui/material/Button";
import Typography from "@mui/material/Typography";
import Checkbox from "@mui/material/Checkbox";
import { FormControlLabel } from "@mui/material";
import axios from "axios";

const Register = () => {
  const [errors, setErrors] = useState({});
  const [formData, setFormData] = useState({
    name: {
      first: "",
      middle: "",
      last: "",
    },
    phone: "",
    email: "",
    password: "",
    image: {
      url: "",
      alt: "",
    },
    address: {
      state: "",
      country: "",
      city: "",
      street: "",
      houseNumber: "",
      zip: "",
    },
    isBuusiness: false,
  });

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    });

    const fieldPath = name.split(".");
    setFormData((prev) => {
      if (fieldPath.length === 1) {
        return { ...prev, [name]: value };
      } else {
        const [parent, child] = fieldPath;
        return { ...prev, [parent]: { ...prev[parent], [child]: value } };
      }
    });
  };

  const handleCancel = () => {
    setFormData({
      firstName: "",
      middleName: "",
      LastName: "",
      Phone: "",
      Email: "",
      Password: "",
      ImageUrl: "",
      ImageAlt: "",
      State: "",
      Country: "",
      City: "",
      Street: "",
      HouseNumber: "",
      Zip: "",
      isBusinessAccount: false,
    });
  };
  const validateForm = () => {
    const newErrors = {};
    if (
      !formData.name.first ||
      formData.name.first.length < 2 ||
      formData.name.first.length > 10
    ) {
      newErrors.name = "First name must be between 2 and 10 characters";
    }

    if (
      !formData.name.last ||
      formData.name.last.length < 2 ||
      formData.name.last.length > 10
    ) {
      newErrors.name = "Last name must be between 2 and 10 characters";
    }
    const phoneRegex = /^0\d{8,9}$/;
    if (!formData.phone || !phoneRegex.test(formData.phone)) {
      newErrors.phone = "Phone must be a valid phone number";
    }

    const emailRegex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
    if (!formData.email || !emailRegex.test(formData.email)) {
      newErrors.email = "Email must be a valid email address";
    }
    const passwordRegex = {
      uppercase: /[A-Z]/,
      lowercase: /[a-z]/,
      number: /\d/,
      specialChar: /[@#$%^&*-]/,
    };
    if (
      !formData.password ||
      formData.password.length < 9 ||
      !passwordRegex.uppercase.test(formData.password) ||
      !passwordRegex.lowercase.test(formData.password) ||
      !passwordRegex.number.test(formData.password) ||
      !passwordRegex.specialChar.test(formData.password)
    ) {
      newErrors.password =
        "Password must be at least 9 characters and contain an uppercase letter, lowercase letter, number and special character (@#$%^&*-)";
    }

    ["state", "country", "city", "street", "houseNumber", "zip"].forEach(
      (field) => {
        if (!formData.address[field]) {
          newErrors.address = "All address fields are required";
        }
      }
    );

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleRefresh = () => {
    console.log("Validation logic goes here");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    const dataToSend = {
      name: {
        first: formData.name.first,
        middle: formData.name.middle,
        last: formData.name.last,
      },
      phone: formData.phone,
      email: formData.email,
      password: formData.password,
      image: {
        url: formData.image.url,
        alt: formData.image.alt,
      },
      address: {
        state: formData.address.state,
        country: formData.address.country,
        city: formData.address.city,
        street: formData.address.street,
        houseNumber: formData.address.houseNumber,
        zip: formData.address.zip,
      },
    };

    try {
      const response = await axios.post("/api/auth/register", dataToSend, {
        headers: {
          "Content-Type": "application/json",
        },
      });
      const data = response.data;
      console.log(data);
      alert("User registered successfully");
    } catch (error) {
      console.error(error);
      alert("Failed to register user, please try again");
    }

    console.log("Submit logic goes here");
  };

  return (
    <Container>
      <Box sx={{ width: "100%", mt: 5, height: "100vh" }}>
        <Paper elevation={3} sx={{ height: "116vh" }}>
          <Grid container spacing={2} sx={{ p: 3 }}>
            <Grid item xs={12}>
              <Typography variant="h4">Register</Typography>
            </Grid>
            <Grid item xs={12}>
              <Box component="form" onSubmit={handleSubmit}>
                <Grid container spacing={2}>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="First Name"
                      name="name.first"
                      value={formData.name.first}
                      onChange={handleChange}
                    />
                    {errors.name && (
                      <Typography color="error">{errors.name}</Typography>
                    )}
                  </Grid>

                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Middle Name"
                      name="name.middle"
                      value={formData.name.middle}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Last Name"
                      name="name.last"
                      value={formData.name.last}
                      onChange={handleChange}
                    />
                    {errors.name && (
                      <Typography color="error">{errors.name}</Typography>
                    )}
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Password"
                      name="password"
                      type="password"
                      value={formData.password}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Image URL"
                      name="image.url"
                      value={formData.image.url}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Image Alt"
                      name="image.alt"
                      value={formData.image.alt}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="State"
                      name="address.state"
                      value={formData.address.state}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Country"
                      name="address.country"
                      value={formData.address.country}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="City"
                      name="address.city"
                      value={formData.address.city}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Street"
                      name="address.street"
                      value={formData.address.street}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="House Number"
                      name="address.houseNumber"
                      value={formData.address.houseNumber}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <TextField
                      fullWidth
                      label="Zip"
                      name="address.zip"
                      value={formData.address.zip}
                      onChange={handleChange}
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={formData.isBusinessAccount}
                          onChange={handleChange}
                          name="isBusinessAccount"
                          color="primary"
                        />
                      }
                      label="Business Account"
                    />
                  </Grid>
                  <Grid item xs={12}>
                    <Grid container spacing={2}>
                      <Grid item sx={6}>
                        <Button
                          variant="contained"
                          color="secondary"
                          onClick={handleCancel}
                        >
                          Cancel
                        </Button>
                      </Grid>
                      <Grid item>
                        <Button
                          variant="contained"
                          color="primary"
                          onClick={handleRefresh}
                        >
                          Refresh
                        </Button>
                      </Grid>
                      <Grid item sx={6}>
                        <Button
                          variant="contained"
                          color="primary"
                          type="submit"
                        >
                          Submit
                        </Button>
                      </Grid>
                    </Grid>
                  </Grid>
                </Grid>
              </Box>
            </Grid>
          </Grid>
        </Paper>
      </Box>
    </Container>
  );
};

export default Register;
